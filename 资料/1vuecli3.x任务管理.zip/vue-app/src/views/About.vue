<template>
  <div class="about">
    <h1>关于我们</h1>
    <p>专注于前端在线课程的开发和录制</p>
  </div>
</template>
